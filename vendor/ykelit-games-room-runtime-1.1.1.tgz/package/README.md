# @ykelit/games-room-runtime

Shared room, presence and reconnect runtime for YkeLit games. It owns guest
sessions, room membership, host transfer, connection leases, revision CAS,
request idempotency and room expiry. A game adapter owns only game-rule state
and viewer-specific projection.

## Invariants

- Guest cookies contain a 256-bit opaque token; stores persist SHA-256 hashes only.
- Every game command includes `protocolVersion`, `requestId` and `expectedRevision`.
- Room mutations use atomic compare-and-set; Redis failure is surfaced and never
  downgraded to an in-process store.
- A seat can have multiple connections. Only the final disconnect starts its
  reconnect window.
- Distributed sweep/timer workers use ownership-safe `RedisLockProvider`; room
  updates are fanned out between instances with `RedisRoomEventBus`.
- Adapters cannot mint credentials, edit presence or bypass revision checks.
- Server-owned timers use `executeForParticipant`, so automated actions keep the
  same request replay, adapter validation and revision CAS guarantees as clients.
- `rebuildTimers` is invoked once per room when a new runtime process first
  restores it, allowing persisted deadlines to be scheduled after restart.
- Hidden information must be returned through `projectForViewer`.

## Adapter

```ts
import {
  MemoryRoomStore,
  RoomRuntime,
  pauseWhenRequiredPlayerMissing,
  type GameAdapter,
} from "@ykelit/games-room-runtime";

const runtime = new RoomRuntime(adapter, {
  store: new MemoryRoomStore(), // tests only
  disconnectPolicy: pauseWhenRequiredPlayerMissing(),
});
```

Production services must use `RedisRoomStore` with a dedicated key namespace:
`room:v1:<gameId>:`. Call `runtime.ready()` from readiness checks and stop
accepting traffic when it fails.

`runAdapterContract` is exported from `@ykelit/games-room-runtime/testkit` for
framework-neutral adapter validation.

Lifecycle hooks receive `paused`, `resumed` and `host-transferred` only after
the corresponding CAS update succeeds. Metrics hooks expose
`room_created_total`, `reconnect_success_total`, `room_cas_conflict_total`,
`room_expired_total` and `room_pause_duration_ms`; an initial `room.attach` is
not counted as a reconnect.
